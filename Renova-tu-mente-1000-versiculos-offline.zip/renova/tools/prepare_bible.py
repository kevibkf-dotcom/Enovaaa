#!/usr/bin/env python3
"""Genera exactamente 1000 versículos bíblicos offline para la APK.
La descarga ocurre SOLO durante la compilación en GitHub. La APK final no
incluye permiso INTERNET y lee los datos desde assets locales.
"""
import json, os, re, urllib.request

URL = 'https://raw.githubusercontent.com/Amosamevor/Bible-json/main/versions/es/REINA%20VALERA%201909.json'
ASSETS = os.path.join('app','src','main','assets')
DEST = os.path.join(ASSETS, 'bible-data.js')
MOTIV = os.path.join(ASSETS, 'motivational-data.js')
BOOKS = ['Genesis','Exodus','Leviticus','Numbers','Deuteronomy','Joshua','Judges','Ruth','1 Samuel','2 Samuel','1 Kings','2 Kings','1 Chronicles','2 Chronicles','Ezra','Nehemiah','Esther','Job','Psalms','Proverbs','Ecclesiastes','Song of Solomon','Isaiah','Jeremiah','Lamentations','Ezekiel','Daniel','Hosea','Joel','Amos','Obadiah','Jonah','Micah','Nahum','Habakkuk','Zephaniah','Haggai','Zechariah','Malachi','Matthew','Mark','Luke','John','Acts','Romans','1 Corinthians','2 Corinthians','Galatians','Ephesians','Philippians','Colossians','1 Thessalonians','2 Thessalonians','1 Timothy','2 Timothy','Titus','Philemon','Hebrews','James','1 Peter','2 Peter','1 John','2 John','3 John','Jude','Revelation']
ALIASES = {re.sub(r'[^a-z0-9]','',b.lower()):b for b in BOOKS}
ALIASES.update({'songofsongs':'Song of Solomon','canticles':'Song of Solomon','revelations':'Revelation','psalm':'Psalms','acts of the apostles':'Acts'})

def norm(s): return re.sub(r'[^a-z0-9]','',str(s).lower())
def book_name(v):
    if v is None: return None
    n=norm(v)
    return ALIASES.get(n) or ALIASES.get(n.replace('bookof',''))

def add(out,b,c,v,t):
    try:c=int(c);v=int(v)
    except:return
    if b in out and c>0 and v>0 and t is not None:
        out[b].setdefault(str(c),[])
        if not any(x['verse']==v for x in out[b][str(c)]): out[b][str(c)].append({'verse':v,'text':str(t).strip()})

def parse(raw):
    out={b:{} for b in BOOKS}
    def walk(node,b=None,c=None):
        if isinstance(node,list):
            for x in node: walk(x,b,c)
            return
        if not isinstance(node,dict): return
        nb=book_name(node.get('book') or node.get('book_name') or node.get('bookName')) or b
        nc=node.get('chapter') or node.get('chapter_number') or node.get('chapterNumber') or c
        nv=node.get('verse') or node.get('verse_number') or node.get('verseNumber')
        txt=node.get('text') or node.get('verse_text') or node.get('verseText') or node.get('content')
        if isinstance(nc,dict): nc=nc.get('number') or nc.get('num') or nc.get('id')
        if nb and nc and nv and txt is not None: add(out,nb,nc,nv,txt)
        for k,v in node.items():
            kb=book_name(k) or nb
            if isinstance(k,str) and k.isdigit():
                n=int(k)
                if kb and c is None and 1<=n<=150: walk(v,kb,n)
                elif kb and c is not None and 1<=n<=200:
                    if isinstance(v,(str,int,float)): add(out,kb,c,n,v)
                    else: walk(v,kb,c)
                else: walk(v,kb,c)
            elif k not in ('book','book_name','bookName','chapter','chapter_number','chapterNumber','verse','verse_number','verseNumber','text','verse_text','verseText','content'):
                walk(v,kb,nc)
    walk(raw)
    for b in out:
        for c in out[b]: out[b][c].sort(key=lambda x:x['verse'])
    return out

def score(text):
    s=text.lower()
    words=['fortal','ánimo','animo','esper','fe','confí','confi','paz','amor','fuerza','valent','gozo','alegr','esperanza','consuelo','refugio','ayuda','temor','miedo','gracia','misericordia','perdón','perdon','sabidur','sabiduria','corazón','corazon','vida','camino','bien','paciencia','persever','oración','oracion','bendic','salv','luz','verdad','fiel','promesa','descanso','sanar','sanidad','victoria','triunfo','justicia']
    return sum(2 if w in s else 0 for w in words)

def main():
    os.makedirs(ASSETS,exist_ok=True)
    req=urllib.request.Request(URL,headers={'User-Agent':'RenovaTuMente-offline-builder'})
    with urllib.request.urlopen(req,timeout=90) as r: raw=json.load(r)
    bible=parse(raw)
    allv=[]
    for b in BOOKS:
        for c,vs in bible[b].items():
            for v in vs: allv.append((score(v['text']),b,int(c),v['verse'],v['text']))
    if len(allv)<1000:
        raise SystemExit(f'ERROR: solo se encontraron {len(allv)} versículos; se necesitan 1000')
    allv.sort(key=lambda x:(-x[0],x[1],x[2],x[3]))
    chosen=allv[:1000]
    # Mantener exactamente los 1000 seleccionados y ordenarlos por libro/capítulo/versículo.
    chosen.sort(key=lambda x:(BOOKS.index(x[1]),x[2],x[3]))
    bible1000={}
    for _,b,c,v,t in chosen:
        bible1000.setdefault(b,{}).setdefault(str(c),[]).append({'verse':v,'text':t})
    with open(DEST,'w',encoding='utf-8') as f:
        f.write('window.RTM_BIBLE='+json.dumps(bible1000,ensure_ascii=False,separators=(',',':'))+';')
    data=[{'book':b,'chapter':c,'verse':v,'text':t} for _,b,c,v,t in chosen]
    with open(MOTIV,'w',encoding='utf-8') as f:
        f.write('window.RTM_MOTIVATIONAL='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';')
    print(f'OK: {len(chosen)} versículos incluidos offline.')

if __name__=='__main__': main()
