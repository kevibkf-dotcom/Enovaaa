RENOVÁ TU MENTE — proyecto Android

Incluye una app Android nativa tipo WebView y una versión web instalable (PWA).
Funciones: calendario mensual con estados, racha actual, conteo de días, lista de 7 días,
versículos bíblicos, lector de capítulos bíblicos extensos (Reina-Valera 1909), explicaciones y reflexión, registro de gimnasio/recuperación, estrategia para momentos difíciles y nota personal. Los datos se guardan
localmente en el dispositivo con localStorage.

IMPORTANTE:
- Este paquete contiene el PROYECTO FUENTE, no un APK compilado.
- En este entorno no está instalado Android SDK/Gradle, por lo que no puedo compilar ni verificar
  un APK aquí.
- Para compilar: abrir la carpeta en Android Studio con Android SDK instalado, sincronizar Gradle
  y elegir Build > Build APK(s). El APK de depuración suele quedar en app/build/outputs/apk/debug/.
- Para probar sin compilar APK: servir app/src/main/assets por HTTPS y añadir la web app desde Chrome
  usando el menú > Añadir a pantalla de inicio. La PWA necesita alojarse para ser instalable como PWA.
- El calendario y las notas se guardan localmente; no hay cuenta ni sincronización en la nube.


NOVEDAD BIBLIA COMPLETA (v2): en la sección “Conocé la Biblia” se puede seleccionar cualquiera de los 1.000 versículos, capítulo y versículo, cargar un capítulo o ir a un versículo, guardar favoritos y compartir/copiar referencias. La Biblia Reina-Valera 1909 y 1000 versículos seleccionados por temática motivacional se descargan durante la compilación y quedan empaquetados dentro de la APK. La aplicación instalada no solicita permiso de Internet y puede usarse completamente sin conexión. Los favoritos y registros quedan guardados localmente en el dispositivo.
