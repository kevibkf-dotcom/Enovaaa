# Renová tu mente — Biblia sin conexión

El explorador se alimenta de `app/src/main/assets/bible-data.js`, incluido en la APK. Por eso la app instalada no necesita conexión para leer la Biblia.

## Paso necesario en GitHub Actions

Antes de `gradle assembleDebug`, añadí este paso al workflow (con el directorio actual del proyecto en `renova`):

```yaml
      - name: Incluir Biblia completa para uso sin conexión
        run: |
          cd renova
          python3 tools/prepare_bible.py
```

El paso descarga el JSON público Reina-Valera 1909 durante la compilación, lo transforma a un recurso JavaScript local y verifica que haya al menos 66 libros y 30.000 versículos. La descarga ocurre solo en el servidor de compilación; el APK resultante incluye el texto. Si la fuente cambia de formato o la descarga falla, el build falla explícitamente en vez de generar una app sin Biblia.

La traducción Reina-Valera 1909 se distribuye como texto de dominio público/CC0 según la fuente: https://github.com/Amosamevor/Bible-json


## 1000 versículos motivacionales
El workflow genera `motivational-data.js` a partir de la Biblia completa incluida en la compilación y selecciona 1000 versículos por relevancia temática (fe, esperanza, paz, fortaleza, amor, ánimo, etc.).
